/**
 * Copyright (c) 2017 Early Warning Services, LLC. All Rights Reserved.
 * 
 * Internal use only. Confidential and proprietary. You may not disclose, copy
 * or distribute this material for any purpose in any medium without the
 * expressed written consent of Early Warning Services, LLC.
 * 
 */
package com.earlywarning.authentication.stepdefs;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.util.Map;

import com.earlywarning.authentication.ccv.CCVEchoRequest;
import com.earlywarning.authentication.ccv.CCVRequest;
import com.earlywarning.authentication.ccv.CCVRequestCreator;
import com.earlywarning.authentication.ccv.CCVResponseValidator;
import com.earlywarning.authentication.ccv.CcvRestCalls;

import cucumber.api.DataTable;
import cucumber.api.java8.En;
import io.restassured.RestAssured;
import io.restassured.response.Response;

/**
 * <p>A Cucumber step definition class using Java 8 lambdas. These step definitions
 * act on messages (requests and responses) that are defined in the com.earlywarning.authentication.common
 * package, which is how this class got it's name. The step definitions included in this class are 
 * described below.</p>
 * <P>The 'Given' Step Definitions.<ol>
 * 	<li><code>Given The CCV application is running</code> - Verifies the Call Center Verification
 * 		application is running on the server by making a call to the CCVEcho endpoint.</li>
 * 	<li><code>Given the ccvrequest has the values</code> - Creates a CCV Request (JSON) from the 
 * 		DataTable that is passed in.</li>
 * 	<li><code>Given I have a request with the values &ltstring&gt &ltstring&gt</code> - A Step Definition
 * 		that uses the data from an Examples element. For this implementation the 2 strings are a
 * 		request id and a message.</li>
 * 	<li><code>Given the following request with invalid fields</code> - This Step Definition takes
 * 		a formatted (though invalid) JSON message. The format of this step definition is<br>
 * 		<code>Given the following request with invalid fields<br>
 * 		"""<br>
 * 			&ltthe request&gt<br>
 * 		"""</code><br>
 * 		The triple quotes are required for this to work.</li></ol></p>
 * <p>The 'When' Step Definitions.<ol>
 * 	<li><code>When the request is sent to the service</code> - This step definition sends the 
 * 		CCV Request to the endpoint</li>
 * 	<li><code>When the invalid request is sent to the service</code> - Sends the formatted request
 * 		to the CCV service/<li>
 * 	<li><code>When the message is sent</code> - Sends the CCV Evho Request to the CCVEcho service.</li></ol></p>
 * <p>The 'Then' Step Definitions.<ol>
 * 	<li><code>Then the response has the values</code> - This step definition takes a data table as a 
 * 		parameter. The data table lists the response elements as name value pairs.</li></ol></p>
 * @author cornettl
 *
 */
public class CcvStepDef implements En {
	private static Response response;
	private static CCVEchoRequest request;
	private static CCVRequest ccvRequest;
	private static String invalidRequest;
	
	public CcvStepDef()  {
		Given("^The CCV application is running$", () -> {
		    boolean isRunning = false;
		    isRunning = CcvRestCalls.isCcvRunning();
		    assertEquals(true, isRunning);
		});
		
		Given("^the ccvrequest has the values$", (DataTable data) -> {
			Map<String, String> map = data.asMap(String.class, String.class);
			ccvRequest = CCVRequestCreator.createRequest(map);
		});

		
		Given("^I have a request with the values \"([^\"]*)\" \"([^\"]*)\"$", (String requestId, String message) -> {
			request = new CCVEchoRequest();
			
			request.setRequestId(requestId);
			request.setMessage(message);
		});
		
		Given("^the following request with invalid fields$", (String request) -> {
			invalidRequest = request;
			System.out.println("tada");
		});
		
		When("^the request is sent to the service$", () -> {
		    // Write code here that turns the phrase above into concrete actions
			response = CcvRestCalls.sendRequest(ccvRequest);
			RestAssured.reset();
			System.out.println("tada");
		});
		
		When("^the invalid request is sent to the service$", () -> {
			response = CcvRestCalls.sendRequest(invalidRequest);
		});
		
		
		When("^the message is sent$", () -> {
		    // Write code here that turns the phrase above into concrete actions
		    response = CcvRestCalls.postEcho(request);
			
		});
		
		Then("^the response has the values$", (DataTable data) -> {
		    // Write code here that turns the phrase above into concrete actions
		    // For automatic transformation, change DataTable to one of
		    // List<YourType>, List<List<E>>, List<Map<K,V>> or Map<K,V>.
		    // E,K,V must be a scalar (String, Integer, Date, enum etc)
			Map<String, String> map = data.asMap(String.class, String.class);
			boolean status = CCVResponseValidator.validateResponse(response, map);
			System.out.println(status);
			assertTrue(status);
		});
		
	}

}

/**
 * Copyright (c) 2017 Early Warning Services, LLC. All Rights Reserved.
 * 
 * Internal use only. Confidential and proprietary. You may not disclose, copy
 * or distribute this material for any purpose in any medium without the
 * expressed written consent of Early Warning Services, LLC.
 * 
 */
package com.earlywarning.authentication.ccv;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import lombok.Builder;
import lombok.Data;

/**
 * A POJO that represents the MatchNameAttributeKey of the CCVRequest object.
 * @author cornettl
 *
 */
@JsonInclude(Include.NON_NULL)
@Data
@Builder
public class MatchNameAttributeKey {
	private String FirstName;
	private String MiddleName;
	private String LastName;
}

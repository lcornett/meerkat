/**
 * Copyright (c) 2017 Early Warning Services, LLC. All Rights Reserved.
 * 
 * Internal use only. Confidential and proprietary. You may not disclose, copy
 * or distribute this material for any purpose in any medium without the
 * expressed written consent of Early Warning Services, LLC.
 * 
 */
/**
 * <h1>Overview</h1>
 * The startup package contains classes that will be used whenever cucumber runs.
 * one of the classes, AuthenticationRunner, is only used when and if the tests
 * are run by junit. See the JavaDoc for this class to find out the details. 
 * The other classes will only contain static methods which can be called from 
 * anywhere in the framework.
 * <br><h1>Running Cucumber from a script</h1>
 * To be implemented
 * <br><h1>Running JUnit from a script</h1>
 * To be implemented
 * @author cornettl
 *
 */
package com.earlywarning.authentication.startup;
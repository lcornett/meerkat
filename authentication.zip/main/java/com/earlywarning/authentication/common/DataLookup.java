/**
 * Copyright (c) 2017 Early Warning Services, LLC. All Rights Reserved.
 * 
 * Internal use only. Confidential and proprietary. You may not disclose, copy
 * or distribute this material for any purpose in any medium without the
 * expressed written consent of Early Warning Services, LLC.
 * 
 */
package com.earlywarning.authentication.common;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

/**
 * POJO to represent the dataLookup json object
 * @author cornettl
 *
 */
@Data
@JsonInclude(Include.NON_EMPTY)
public class DataLookup {
	@JsonProperty("FinalTargetUrl")
	private FinalTargetUrl finalTargetUrl;
	private MobileNetworkOperator mobileNetworkOperator;
	private DeviceIp deviceIp;
//	private ConsentCollectedDate consentCollectedDate;
	private String consentCollectedDate;
//	private ConsentTransactionId consentTransactionId;
	private String consentTransactionId;
//	private ConsentDescription consentDescription;
	private String consentDescription;
	private LastVerificationDate lastVerificationDate;
	private Vfp vfp;
	private EnterprisePhoneNumber enterprisePhoneNumber;
	private CallArrivalTime callArrivalTime;
	private String email;
	private Name name;
	private Address address;

}

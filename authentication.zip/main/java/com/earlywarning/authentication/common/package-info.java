/**
 * Copyright (c) 2017 Early Warning Services, LLC. All Rights Reserved.
 * 
 * Internal use only. Confidential and proprietary. You may not disclose, copy
 * or distribute this material for any purpose in any medium without the
 * expressed written consent of Early Warning Services, LLC.
 * 
 */
/**
 * <p id="package_description">This package contains all of the classes required to create and validate the 
 * Authentify JSON messages. Most of the classes are POJOs that utilize the lombok
 * Data annotation as well as the JsonInclude(Include.NON_EMPTY) annotation. There 
 * are quite a few classes (objects) that a message is composed of so a heirarchical
 * representation of the objects are presented here.<ul>
 *  <li>Request<ul>
 * 		<li>Data<ul>
 * 			<li>DataLookup<ul>
 * 				<li>FinalTargetUrl</li>
 * 				<li>MobileNetworkOperator</li>
 * 				<li>DeviceIp</li>
 * 				<li>ConsentCollectedDate</li>
 * 				<li>ConsentTransactionId</li>
 * 				<li>ConsentDescription</li>
 * 				<li>LastVerificationDate</li>
 * 				<li>Vfp</li>
 * 				<li>EnterprisePhoneNumber</li>
 * 				<li>CallArrivalTime</li>
 * 				<li>Name<ul>
 * 					<li>FirstName</li>
 * 					<li>MiddleName</li>
 * 					<li>LastName</li>
 * 				</ul></li>
 * 				<li>Address<ul>
 * 					<li>StreetAddress</li>
 * 					<li>ExtendedAddress</li>
 * 					<li>City</li>
 * 					<li>PostalCode</li>
 * 					<li>Region</li>
 * 					<li>Country</li>
 *				</ul></li>
 *			</ul></li>
 * 			</ul></li>
 * 			<li>NamedData<ul>
 * 				<li>DataItem</li>
 * 			</ul></li>
 * 			<li>User<ul>
 * 				<li>CardInfo</li>
 * 			</ul></li>
 * 		</ul></li>
 * 		<li>User</li>	
 * 	</ul></li>
 * Each of the objects may or may not have other fields that are not objects. These are not listed here.</p>
 * <h3 id="tags">Annotations</h3>
 * <p>The lombok Data annotation provides the implementation for the setters and getters as well as the 
 * 'toString(), hashCode() and equals() methods without having to code these boilerplate methods. Because
 * these methods are provided by lombok and not specifically coded, the Java Doc for the class does not include 
 * the lombok provided methods.</p>
 * <p>The JsonInclude annotation is provided by the jackson-databind jar. The JsonInclude annotation
 * is used typically to tell the serializer what fields to include and not include. Typically NON_NULL or
 * NON_EMPTY fields are included.
 * 	 
 * @author cornettl
 *
 */
package com.earlywarning.authentication.common;
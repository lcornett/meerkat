/**
 * Copyright (c) 2017 Early Warning Services, LLC. All Rights Reserved.
 * 
 * Internal use only. Confidential and proprietary. You may not disclose, copy
 * or distribute this material for any purpose in any medium without the
 * expressed written consent of Early Warning Services, LLC.
 * 
 */
package com.earlywarning.authentication.common;

import com.earlywarning.authentication.startup.Env;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import lombok.Data;

/**
 * POJO to represent the request object
 * @author cornettl
 *
 */
@Data
@JsonInclude(Include.NON_EMPTY)
public class Request {
	private String clientId = "Authentify_Test"; // default value
	private String license = Env.getProperty(Env.getProperty("environment") + "License");
	private String app = "mobileLookupProd"; // default value
	private String clientAcctId = "QATest"; // default value
	private String clientContext = "Authentify_QA_TEST"; // default value
	private String event;
	private com.earlywarning.authentication.common.Data data;
	private User user;
}

/**
 * Copyright (c) 2017 Early Warning Services, LLC. All Rights Reserved.
 * 
 * Internal use only. Confidential and proprietary. You may not disclose, copy
 * or distribute this material for any purpose in any medium without the 
 * expressed written consent of Early Warning Services, LLC.
 * 
 */
package com.earlywarning.jirarestclient.utilities;

import java.awt.Toolkit;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.StringSelection;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;

public class EncryptionListener implements ActionListener, FocusListener {
	PropertyEncryptor encryptor;
	
	public EncryptionListener (PropertyEncryptor encryptor) {
		this.encryptor = encryptor;
	}
	
	public void actionPerformed(ActionEvent e) {
		String cmd = e.getActionCommand();
		Object source = e.getSource();
		
		System.out.println(source);
		switch (cmd) {
			case "Encrypt":
				doEncrypt();
				break;
			case "Copy":
				doCopy();
				break;
		}
		
		if (source == encryptor.txtInput) {
			doEncrypt();
			System.out.println("here");
			System.out.println(encryptor.btnEncrypt.hasFocus());
			encryptor.btnEncrypt.setEnabled(false);
		}
	}

	
	public void focusGained(FocusEvent e) {
		// not used		
	}

	@Override
	public void focusLost(FocusEvent e) {
		System.out.println(e);
		if (encryptor.txtResult.getText().isEmpty()) {
			encryptor.btnEncrypt.setEnabled(true);
		}
	}
	
	private void doEncrypt() {
		Encryption encryption = new Encryption();
		String encryptedText = null;
		
		encryptedText = encryption.encrypt(encryptor.txtInput.getText());
		encryptor.txtResult.setText(encryptedText);
		encryptor.txtInput.setEnabled(false);
		encryptor.btnCopy.setEnabled(true);
		encryptor.btnCopy.requestFocusInWindow();
		if (encryptor.btnEncrypt.isEnabled()) {
			System.out.println(encryptor.btnEncrypt.isEnabled());
			encryptor.btnEncrypt.setEnabled(false);
		}
		
	}
	
	private void doCopy() {
		String encrypted = encryptor.txtResult.getText();
		StringSelection selection = new StringSelection(encrypted);
		Clipboard clpbd = Toolkit.getDefaultToolkit().getSystemClipboard();
		
		clpbd.setContents(selection, null);
		if (!encryptor.txtInput.isEnabled()) {
			encryptor.txtInput.setEnabled(true);
		}
		
		encryptor.txtInput.requestFocusInWindow();
		encryptor.btnCopy.setEnabled(false);
		encryptor.txtInput.setText("");
		encryptor.txtResult.setText("");
		encryptor.txtResult.setText("");
		encryptor.txtInput.setEnabled(true);
		System.out.println("Tada");
	}

}


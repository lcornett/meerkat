/**
 * 
 */
/**
 * @author cornettl
 *
 */
package com.earlywarning.jirarestclient;
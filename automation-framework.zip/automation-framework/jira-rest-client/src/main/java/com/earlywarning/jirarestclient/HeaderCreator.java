/**
 * Copyright (c) 2017 Early Warning Services, LLC. All Rights Reserved.
 * 
 * Internal use only. Confidential and proprietary. You may not disclose, copy
 * or distribute this material for any purpose in any medium without the
 * expressed written consent of Early Warning Services, LLC.
 * 
 */

package com.earlywarning.jirarestclient;

import java.nio.charset.Charset;
import java.util.Map;
import java.util.Set;

import org.apache.commons.codec.binary.Base64;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;

import com.earlywarning.jirarestclient.utilities.Encryption;

public class HeaderCreator {
	
	@Value("${user}")
	String username;
	
	@Value("${password}")
	String password;

	public HttpHeaders createHeaders(Map<String, String> headers) {
		HttpHeaders httpHeaders = new HttpHeaders();
		Set<String> keys = headers.keySet();
		
		for (String key : keys) {
			switch (key) {
			case "Authorization":
				httpHeaders.add(key, headers.get(key));
				break;
			case "Content-Type":
				httpHeaders.add(key, headers.get(key));
				break;
			}
		}
		return httpHeaders;
	}
	
	public String encodeCreds() {
		Encryption enc = new Encryption();
		String auth = enc.decrypt(username) + ":" + enc.decrypt(password);
		byte[] encodedAuth = Base64.encodeBase64(auth.getBytes(Charset.forName("US-ASCII")));
		String headerValue = "Basic " + new String(encodedAuth);
		return headerValue;
	}

}

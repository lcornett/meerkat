package com.earlywarning.jirarestclient;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyMap;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.io.File;
import java.io.IOException;
import java.net.URISyntaxException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;



public class ExporterTest {
	RestTemplateFactory factory;
	Exporter exporter;
	ResponseEntity<byte[]> response;
	HttpHeaders headers;
	
	@SuppressWarnings("unchecked")
	@Before
	public void setUp() throws Exception {
		List<String> list = new ArrayList<String>();
		list.add("\"String=string.feature\"");
				
		headers = mock(HttpHeaders.class);
		when(headers.containsKey(anyString())).thenReturn(true);
		when(headers.get(any())).thenReturn(list);
		
		HeaderCreator creator = mock(HeaderCreator.class);
		when(creator.encodeCreds()).thenReturn("String");
		when(creator.createHeaders(anyMap())).thenReturn(headers);
		
		response = mock(ResponseEntity.class);
		when(response.getStatusCode()).thenReturn(HttpStatus.OK);
		when(response.getHeaders()).thenReturn(headers);
		when(response.getBody()).thenReturn("String".getBytes());

		RestTemplate template = mock(RestTemplate.class);
		when(template.exchange(any(), any(), any(), eq(byte[].class))).thenReturn(response);

		
		factory = mock(RestTemplateFactory.class);
		when(factory.getObject()).thenReturn(template);
	
		exporter = new Exporter(factory);
		exporter.creator = creator;
		exporter.endpoint = "rest/raven/1.0/export/test";
		exporter.host = "https://jira.ews.int/";
		exporter.outputDir = "features";
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testExporter() {
		exporter = null;
		exporter = new Exporter(factory);
		assertNotNull(exporter);
	}

	@Test
	public void testExporterNullArg() {
		exporter = new Exporter(null);
		assertNotNull(exporter);
	}

	@Test
	public void testExecuteRequest() throws Exception {
		String issues = "QCA-209;QCA-229";
		exporter.executeRequest(issues);
		assertTrue(true);
	}

	@Test(expected=NullPointerException.class)
	public void testExecuteRequestNullFactory() throws Exception {
		String issues = "QCA-209;QCA-229";
		exporter = new Exporter(null);
		exporter.executeRequest(issues);
		assertTrue(true);
	}

	@Test(expected=URISyntaxException.class)
	public void testExecuteRequestBadUrl() throws Exception {
		String issues = "QCA-209;QCA-229";
		exporter.host = "%";
		exporter.executeRequest(issues);
		assertTrue(true);
	}

	@Test
	public void testExecuteRequestSingleFeature() throws Exception {
		String issues = "QCA-209";
		exporter.executeRequest(issues);
		assertTrue(true);
	}

	@Test
	public void testExecuteRequestNoOutputDir() throws Exception {
		String issues = "QCA-209";
		exporter.outputDir = "nonexist";
		exporter.executeRequest(issues);
		assertTrue(true);
	}

	@Test
	public void testExecuteRequestNoZipOut() throws Exception {
		File dir = new File("features");
		System.out.println(dir.exists());
		
		String issues = "QCA-209;QCA-229";
		exporter.outputDir = "nonexist";
		exporter.executeRequest(issues);
		assertTrue(true);
	}
	
	@Test
	public void test() throws Exception {
		String filename = "src/test/resources/FeatureBundle.zip";
		when(response.getBody()).thenReturn(getFileBytes(filename));
		List<String> list = new ArrayList<String>();
		list.add("string=\"FeatureBundle.zip\"");
		when(headers.get(any())).thenReturn(list);
		
		String issues = "QCA-209;QCA-229";
		exporter.executeRequest(issues);
		assertTrue(true);

	}
	
	byte[] getFileBytes(String filename) {
		byte[] data = null;
		
		try {
			Path path = Paths.get(filename);
			data = Files.readAllBytes(path);
		} catch (IOException e) {
			e.printStackTrace();
		}		
		return data;
	}

}

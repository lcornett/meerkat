package com.earlywarning.jirarestclient;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class RestTemplateFactoryTest {
	private static RestTemplateFactory factory = new RestTemplateFactory();
	
	@Before
	public void setUp() throws Exception {
		
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testAfterPropertiesSet() throws Exception {
		factory.afterPropertiesSet();
		assertNotNull(factory.getObject());
	}

	@Test
	public void testGetObject() throws Exception {
		assertNotNull(factory.getObject());
	}

	@Test
	public void testGetObjectType() {
		String expected = "class org.springframework.web.client.RestTemplate";
		Class<?> type = null;
		type = factory.getObjectType();
		
		assertEquals(expected, type.toString());
	}
	@Test
	public void testIsSingleton() {
		assertTrue(factory.isSingleton());
	}

}

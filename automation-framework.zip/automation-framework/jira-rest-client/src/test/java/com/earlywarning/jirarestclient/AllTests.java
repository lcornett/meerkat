package com.earlywarning.jirarestclient;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

@RunWith(Suite.class)
@SuiteClasses({ ExporterTest.class, ImporterTest.class, RestClientTest.class, HeaderCreatorTest.class, RestTemplateFactoryTest.class,
	HttpComponentsClientHttpRequestFactoryBasicAuthTest.class})
public class AllTests {

}

/**
 * Copyright (c) 2017 Early Warning Services, LLC. All Rights Reserved.
 * 
 * Internal use only. Confidential and proprietary. You may not disclose, copy
 * or distribute this material for any purpose in any medium without the 
 * expressed written consent of Early Warning Services, LLC.
 * 
 */
package com.earlywarning.authentication.ccv;

import static com.earlywarning.authentication.ccv.CCVFieldConstants.CONFIDENCE_ADDRESS;
import static com.earlywarning.authentication.ccv.CCVFieldConstants.CONFIDENCE_EMAIL;
import static com.earlywarning.authentication.ccv.CCVFieldConstants.CONFIDENCE_NAME;
import static com.earlywarning.authentication.ccv.CCVFieldConstants.EVENT_TYPE;
import static com.earlywarning.authentication.ccv.CCVFieldConstants.LAST_CHANGED_DATE;
import static com.earlywarning.authentication.ccv.CCVFieldConstants.MCV_ADDITIONAL_INFO;
import static com.earlywarning.authentication.ccv.CCVFieldConstants.MCV_DESCRIPTION;
import static com.earlywarning.authentication.ccv.CCVFieldConstants.MCV_STATUS;
import static com.earlywarning.authentication.ccv.CCVFieldConstants.MI_ADDITIONAL_INFO;
import static com.earlywarning.authentication.ccv.CCVFieldConstants.MI_DESCRIPTION;
import static com.earlywarning.authentication.ccv.CCVFieldConstants.MI_STATUS;
import static com.earlywarning.authentication.ccv.CCVFieldConstants.MOBILE_IDENTITY_CREATED_DATE;
import static com.earlywarning.authentication.ccv.CCVFieldConstants.MOBILE_IDENTITY_TRANSACTION_ID;
import static com.earlywarning.authentication.ccv.CCVFieldConstants.MOBILE_OPERATOR_NAME;
import static com.earlywarning.authentication.ccv.CCVFieldConstants.MOBILE_STATUS_TRANSACTION_ID;
import static com.earlywarning.authentication.ccv.CCVFieldConstants.MS_ADDITIONAL_INFO;
import static com.earlywarning.authentication.ccv.CCVFieldConstants.MS_DESCRIPTION;
import static com.earlywarning.authentication.ccv.CCVFieldConstants.MS_STATUS;
import static com.earlywarning.authentication.ccv.CCVFieldConstants.RESPONSE_ADDITIONAL_INFO;
import static com.earlywarning.authentication.ccv.CCVFieldConstants.RESPONSE_DESCRIPTION;
import static com.earlywarning.authentication.ccv.CCVFieldConstants.RESPONSE_MOBILE_NUMBER;
import static com.earlywarning.authentication.ccv.CCVFieldConstants.RESPONSE_PAYFONE_ALIAS;
import static com.earlywarning.authentication.ccv.CCVFieldConstants.RESPONSE_REQUEST_ID;
import static com.earlywarning.authentication.ccv.CCVFieldConstants.RESPONSE_STATUS;
import static com.earlywarning.authentication.ccv.CCVFieldConstants.STATUS_INDEX;

import java.util.Map;
import java.util.Set;

import com.earlywarning.authentication.common.ApiDriver;

import io.restassured.response.Response;
import lombok.extern.log4j.Log4j2;

@Log4j2
public class CCVResponseValidator {
	static ApiDriver driver = new ApiDriver("json", "");
	static Map<String, String> map;
	static boolean result = true;
	
	public static boolean validateResponse(Response response, Map<String, String> map) {
		CCVResponseValidator.map = map;
		Set<String> keys = map.keySet();
		
		try {
			int x = 0;
			for (String key : keys) {
				switch (key) {
				case "AdditionalInfo":
					validate(response, RESPONSE_ADDITIONAL_INFO, map.get(key));
					break;
				case "Address":
					validate(response, CONFIDENCE_ADDRESS, map.get(key));
					break;
				case "Description":
						validate(response, RESPONSE_DESCRIPTION, map.get(key));
						break;
					case "Email":
						validate(response, CONFIDENCE_EMAIL, map.get(key));
						break;
					case "EventType":
						validateList(response, EVENT_TYPE, map.get(key));
						break;
					case "LastChangedDate":
						validateList(response, LAST_CHANGED_DATE, map.get(key));
						break;
					case "MCV-AdditionalInfo":
						validate(response, MCV_ADDITIONAL_INFO, map.get(key));
						break;
					case "MCV-Description":
						validate(response, MCV_DESCRIPTION, map.get(key));
						break;
					case "MCV-Status":
						validate(response, MCV_STATUS, map.get(key));
						break;
					case "MI-AdditionalInfo":
						validate(response, MI_ADDITIONAL_INFO, map.get(key));
						break;
					case "MI-Description":
						validate(response, MI_DESCRIPTION, map.get(key));
						break;
					case "MI-Status":
						validate(response, MI_STATUS, map.get(key));
						break;
					case "MobileIdentityCreatedDate":
						validate(response, MOBILE_IDENTITY_CREATED_DATE, map.get(key));
						break;	
					case "MobileIdentityTransactionId":
						validateTransactionId(response, MOBILE_IDENTITY_TRANSACTION_ID, map.get(key));
						break;
					case "MobileNumber":
						validate(response, RESPONSE_MOBILE_NUMBER, map.get(key));
						break;
					case "MobileOperatorName":
						validate(response, MOBILE_OPERATOR_NAME, map.get(key));
						break;
					case "MobileStatusTransactionId":
						validateTransactionId(response, MOBILE_STATUS_TRANSACTION_ID, map.get(key));
						break;
					case "MS-AdditionalInfo":
						validate(response, MS_ADDITIONAL_INFO, map.get(key));
						break;
					case "MS-Description":
						validate(response, MS_DESCRIPTION, map.get(key));
						break;
					case "MS-Status":
						validate(response, MS_STATUS, map.get(key));
						break;
					case "Name":
						validate(response, CONFIDENCE_NAME, map.get(key));
						break;
					case "PayfoneAlias":
						validate(response, RESPONSE_PAYFONE_ALIAS, map.get(key));
						break;
					case "RequestId":
						validate(response, RESPONSE_REQUEST_ID, map.get(key));
						break;
					case "Status":
						validate(response, RESPONSE_STATUS, map.get(key));
						break;
					case "StatusIndex":
						validate(response, STATUS_INDEX, map.get(key));
						break;
					default:
						String msg = "The element " + key + " is invalid!";
						log.warn(msg);
				}
					System.out.println(++x);	
			}
			
		} catch (Exception e) {
			log.error(e.getMessage());
			log.debug(e.getMessage(), e);
		}
		
		boolean status = result;
		result = true;
		
		return status;
		
	}
	
	private static void validate(Response response, String key, String expected) {
		String actual = null;
		
		actual = driver.retrieveJsonValueString(response, key);
		
		if (!expected.equals(actual)) {
			String msg = "The actual value for key " + key + " is " + actual + " and does not equal the expected value " + expected + ".";
			log.info(msg);
			updateResult(false);
		} else {
			log.info("The " + key + " element was successfully validated");
		}
		
		
	}
	
	private static void updateResult(boolean status) {
		if (result == true && status == false) {
			result = false;
		}
	}

	private static void validateList(Response response, String key, String expected) {
		String actual = null;
		String[] expectedArray = null;
		String[] actualArray = null;
		String regex = ",";
		int elements = 0;
		int matches = 0;
		
		actual = driver.retrieveJsonValueString(response, key).replaceAll("\\[", "").replaceAll("\\]", "");
		actualArray = actual.split(regex);
		
		expectedArray = expected.split(regex);
		
		elements = actualArray.length;
		
		if (expectedArray.length == elements) {
			for (String element : actualArray) {
				for (String expectedElement : expectedArray) {
					if (element.trim().equals(expectedElement)) {
						matches++;
						break;
					} 
				}
			}
		}
		
		if (matches/elements != 1) {
			String msg = "The actual elements for " + key + ": " + actual + ", did not match the expected elements " + expected + ".";
			updateResult(false);
			log.info(msg);
		} else {
			log.info("The " + key + " element was successfully validated");
		}
	}
	
	private static void validateTransactionId(Response response, String key, String expected) {
		// The expected value is irrelevant.
		String actual = null;
		
		actual = driver.retrieveJsonValueString(response, key);
		
		if (null == actual) {
			String msg = "The element " + key + " failed validation.";
			log.info(msg);
			updateResult(false);
		} else {
			String msg = "The " + key + " element was successfully validated.";
			log.info(msg);
		} 
	}
}


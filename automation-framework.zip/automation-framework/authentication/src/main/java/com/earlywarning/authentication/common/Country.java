package com.earlywarning.authentication.common;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import lombok.Data;

/**
 * A POJO that represents the Country element of an Authentify Json
 * request message.
 * This class uses the lombok Data and jackson JsonInclude annotations. 
 * Additional information about these annotations may be found at <a href="{@docRoot}/com/earlywarning/authentication/common/package-summary.html#tags">
 * package-info</a>.
 *
 * @author cornettl
 *
 */
@Data
@JsonInclude(Include.NON_NULL)
public class Country {
	private String value;
}

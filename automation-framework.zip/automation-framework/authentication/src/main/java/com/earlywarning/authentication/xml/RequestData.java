/**
 * Copyright (c) 2017 Early Warning Services, LLC. All Rights Reserved.
 * 
 * Internal use only. Confidential and proprietary. You may not disclose, copy
 * or distribute this material for any purpose in any medium without the 
 * expressed written consent of Early Warning Services, LLC.
 * 
 */
package com.earlywarning.authentication.xml;

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class RequestData {
	@JacksonXmlProperty(localName="xmlns:dat=\"http://xml.authentify.net/CommonDataSchema.xml\"", isAttribute=true)
	private String xmlns = "";
	
	@JacksonXmlProperty(localName="dat:phoneNumber")
	private String phoneNumber;
	
	@JacksonXmlProperty(localName="dat:name")
	private Name name;
	
	@JacksonXmlProperty(localName="dat:address")
	private Address address;
	
	@JacksonXmlProperty(localName="dat:namedData")
	private NamedData namedData;
}


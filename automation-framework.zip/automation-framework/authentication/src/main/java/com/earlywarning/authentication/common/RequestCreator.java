/**
 * Copyright (c) 2017 Early Warning Services, LLC. All Rights Reserved.
 * 
 * Internal use only. Confidential and proprietary. You may not disclose, copy
 * or distribute this material for any purpose in any medium without the
 * expressed written consent of Early Warning Services, LLC.
 * 
 */
package com.earlywarning.authentication.common;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.time.Instant;
import java.util.Map;
import java.util.Set;

import com.earlywarning.authentication.startup.Env;

import lombok.extern.log4j.Log4j2;

/**
 * A class to handle creating a Json Request. 
 * @author cornettl
 *
 */
@Log4j2
public class RequestCreator {
	private static Data data;
	private static DataLookup dataLookup;
	private static MobileNetworkOperator operator;
	private static NamedData namedData;
	private static DataItem dataItem;
	private static Name name;
	private static Address address;
	private static User user;
	private static DataUser dataUser;
	private static CardInfo cardInfo;

	static {
		if (null == data) 
			data = new Data();
		if (null == dataLookup)
			dataLookup = new DataLookup();
		if (null == operator)
			operator = new MobileNetworkOperator();
		if (null == namedData)
			namedData = new NamedData();
		if (null == dataItem) 
			dataItem = new DataItem();
		if (null == name)
			name = new Name();
		if (null == address) 
			address = new Address();
		
	}
	
	/**
	 * Method creates a Json request by creating an instance of the  Request class. 
	 * The class knows which objects to create by looking at the keys in the map. If
	 * a key for an object is not included, the object will not be included in the Request.
	 * @param args The name value pairs of the Json Message
	 * @return An instance of the Request class
	 */
	public static Request createRequest(Map<String, String> args) {
		Request request = new Request();
		request = createRequest(args, request);
		return request;
	}
	
	/**
	 * Method that allows multiple calls to create a Request. The method adds the keys
	 * contained in the map to the already created request.
	 * @param args The name value pairs of the Json message.
	 * @param request An instance of the Request class to add the keys to.
	 * @return An instance of the Request class
	 */
	public static Request createRequest(Map<String, String> args, Request request) {
		Set<String> keys = args.keySet();
		String regex = null;
		
		try {
			for (String key : keys) {
				switch (key) {
				case "app": 
					request.setApp(args.get(key));
					break;
				case "callArrivalTime":
					regex = "get[a-zA-Z]+";
					CallArrivalTime time = new CallArrivalTime();
					
					if (args.get(key).matches(regex)) {
						time.setValue(getArrivalTime());
					} else {
						time.setValue(args.get(key));
					}
					
					dataLookup.setCallArrivalTime(time);
					data.setDataLookup(dataLookup);
					request.setData(data);
					break;
				case "city":
					City city = new City();
					city.setValue(args.get(key));
					address.setCity(city);
					dataLookup.setAddress(address);
					data.setDataLookup(dataLookup);
					request.setData(data);
					break;
				case "clientAcctId":
					request.setClientAcctId(args.get(key));
					break;
				case "clientContext":
					request.setClientContext(args.get(key));
					break;
				case "clientId":
					request.setClientId(args.get(key));
					break;
				case "consentCollectedDate":
					ConsentCollectedDate date = new ConsentCollectedDate();
					date.setValue(getProperty(args.get(key)));
					dataLookup.setConsentCollectedDate(date);
					data.setDataLookup(dataLookup);
					request.setData(data);
					break;	
				case "consentDescription":
					ConsentDescription desc = new ConsentDescription();
					desc.setValue(getProperty(args.get(key)));
					dataLookup.setConsentDescription(desc);
					data.setDataLookup(dataLookup);
					request.setData(data);
					break;
				case "consentTransactionId":
					ConsentTransactionId id = new ConsentTransactionId();
					id.setValue(getProperty(args.get(key)));
					dataLookup.setConsentTransactionId(id);
					data.setDataLookup(dataLookup);
					request.setData(data);
					break;
				case "country":
					Country country = new Country();
					country.setValue(args.get(key));
					address.setCountry(country);
					dataLookup.setAddress(address);
					data.setDataLookup(dataLookup);
					request.setData(data);
					break;
				case "cvv":
					if (null == cardInfo) {
						cardInfo = new CardInfo();
					}
					cardInfo.setCvv(args.get(key));
					data.setCardInfo(cardInfo);
					request.setData(data);
					break;
				case "dataItemName":
					dataItem.setName(args.get(key));
					namedData.setDataItem(dataItem);
					data.setNamedData(namedData);
					request.setData(data);
					break;
				case "dataItemValue":
					dataItem.setValue(args.get(key));
					namedData.setDataItem(dataItem);
					data.setNamedData(namedData);;
					request.setData(data);
					break;					
				case "deviceIp":
					DeviceIp ip = new DeviceIp();
					ip.setValue(args.get(key));
					dataLookup.setDeviceIp(ip);
					data.setDataLookup(dataLookup);
					request.setData(data);
					break;
				case "email":
					dataLookup.setEmail(args.get(key));
					data.setDataLookup(dataLookup);
					request.setData(data);
					break;
				case "enterprisePhoneNumber":
					EnterprisePhoneNumber number = new EnterprisePhoneNumber();
					number.setValue(args.get(key));
					dataLookup.setEnterprisePhoneNumber(number);
					data.setDataLookup(dataLookup);
					request.setData(data);
					break;
				case "event":
					request.setEvent(args.get(key));
					break;
				case "ewDeviceId":
					regex = "^get[a-zA-Z]+";
					
					if (args.get(key).matches(regex)) {
						String value = getStored("data." + key);
						data.setEwDeviceId(value);
					} else {
						data.setEwDeviceId(args.get(key));
					}
					request.setData(data);
					break;
				case "finalTargetUrl":
					FinalTargetUrl url = new FinalTargetUrl();
					url.setValue(args.get(key));
					dataLookup.setFinalTargetUrl(url);
					data.setDataLookup(dataLookup);
					request.setData(data);
					break;	
				case "firstName":
					FirstName first = new FirstName();
					first.setValue(args.get(key));
					name.setFirstName(first);
					dataLookup.setName(name);
					data.setDataLookup(dataLookup);
					request.setData(data);
					break;
				case "lastName":
					LastName last = new LastName();
					last.setValue(args.get(key));
					name.setLastName(last);
					dataLookup.setName(name);
					data.setDataLookup(dataLookup);
					request.setData(data);
					break;
				case "lastVerificationDate":
					LastVerificationDate lastVerified = new LastVerificationDate();
					lastVerified.setValue(args.get(key));
					dataLookup.setLastVerificationDate(lastVerified);
					data.setDataLookup(dataLookup);
					request.setData(data);
					break;					
				case "legacyDeviceId":
					regex = "^get[a-zA-Z]+";
					
					if (args.get(key).matches(regex)) {
						String value = getStored("data." + key);
						data.setLegacyDeviceId(value);
					} else {
						data.setLegacyDeviceId(args.get(key));
					}
					request.setData(data);
					break;					
				case "license":
					request.setLicense(args.get(key));
					break;
				case "middleName":
					MiddleName middle = new MiddleName();
					middle.setValue(args.get(key));
					name.setMiddleName(middle);
					dataLookup.setName(name);
					data.setDataLookup(dataLookup);
					request.setData(data);
					break;
				case "mobileNetworkOperator":
					operator.setValue(args.get(key));
					dataLookup.setMobileNetworkOperator(operator);
					data.setDataLookup(dataLookup);
					request.setData(data);
					break;
				case "newPassword":
					String value = args.get(key);
					if (null == user) {
						user = new User();
					}
					user.setNewPassword(value.equals("spaces") ? "   " : value);
					request.setUser(user);
					break;
				case "password":
					value = args.get(key);
					if (null == user) {
						user = new User();
					}
					user.setPassword(value.equals("spaces") ? "   " : value); 
					request.setUser(user);
					break;
				case "phoneNumber":
					data.setPhoneNumber(getProperty(args.get(key)));
					request.setData(data);
					break;	
				case "postalCode":
					PostalCode code = new PostalCode();
					code.setValue(args.get(key));
					address.setPostalCode(code);
					dataLookup.setAddress(address);
					data.setDataLookup(dataLookup);
					request.setData(data);
					break;
				case "streetAddress":
					StreetAddress street = new StreetAddress();
					street.setValue(args.get(key));
					address.setStreetAddress(street);
					dataLookup.setAddress(address);
					data.setDataLookup(dataLookup);
					request.setData(data);
					break;
				case "region":
					Region region = new Region();
					region.setValue(args.get(key));
					address.setRegion(region);
					dataLookup.setAddress(address);
					data.setDataLookup(dataLookup);
					request.setData(data);
					break;
				case "returnLegacyDeviceId":
					namedData.setReturnLegacyDeviceId(args.get(key));
					data.setNamedData(namedData);
					request.setData(data);
					break;
				case "user":
					user = new User();
					request.setUser(user);
					break;
				case "userId":
					if (null == user) {
						user = new User();
					}
					user.setUserId(args.get(key));
					request.setUser(user);
					break;
				case "uuid":
					if (null == dataUser) {
						dataUser = new DataUser();
					}
					dataUser.setUuid(args.get(key));
					data.setUser(dataUser);
					request.setData(data);
					break;
				case "vfp":
					Vfp vfp = new Vfp();
					vfp.setValue(args.get(key));
					dataLookup.setVfp(vfp);
					data.setDataLookup(dataLookup);
					request.setData(data);
					break;
				default:
					log.error("The message element " + key + " does not exist!");
				}
			}
		} finally {
			user = new User();
		}
		
		return request;
	}
	
	/**
	 * Method that creates an instance of the PollRequest class.
	 * @param ewSID The ewSID of the request
	 * @param poll I don't know what this value is
	 * @return
	 */
	public static PollRequest createPollRequest(String ewSID, String poll) {
		PollRequest request = new PollRequest();
		
		request.setEwSID(ewSID);
		request.setPoll(poll);
		
		return request;		
	}
	
	public static Request createVfpRequest(Request request, String vfpString) {
		Request vfpRequest = new Request();
		Vfp vfp = new Vfp();
		Data data = new Data();
		DataLookup dataLookup = new DataLookup();
		
		vfpRequest.setClientId(request.getClientId());
		vfpRequest.setLicense(request.getLicense());
		vfpRequest.setApp(request.getApp());
		vfpRequest.setClientAcctId(request.getClientAcctId());
		vfpRequest.setClientContext(request.getClientContext());
		vfpRequest.setEvent("mobileAuthFinish");
		
		vfp.setValue(vfpString);
		dataLookup.setVfp(vfp);
		data.setNamedData(request.getData().getNamedData());
		data.setDataLookup(dataLookup);
		vfpRequest.setData(data);		
		
		return vfpRequest;
	}

    public static String getvfp(String redirectURL){
        String vfp;
        try {

            URL url = new URL(redirectURL + "&r=f");
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");
            conn.setRequestProperty("Accept", "application/json");
            conn.connect();
            if (conn.getResponseCode() != 200) {
                throw new RuntimeException("Failed : HTTP error code : "
                        + conn.getResponseCode());
            }

            BufferedReader br = new BufferedReader(new InputStreamReader(
                    (conn.getInputStream())));

            String output;
            System.out.println("Output from Server .... \n");
            while ((output = br.readLine()) != null) {
                System.out.println(output);
                vfp = output.replace("{\"vfp\":\"","").replace("\"}","");
                System.out.println(vfp);
                return vfp;
            }

            conn.disconnect();

        } catch (MalformedURLException e) {

            e.printStackTrace();


        } catch (IOException e) {

            e.printStackTrace();

        }
        return null;
    }
    
    private static String getProperty(String initialValue) {
    	String key = "";
    	String regex = "^get[a-zA-Z]+";
    	String environment = null;
    	String result = null;
    	
    	if (initialValue.matches(regex)) {
    		key = initialValue.replaceFirst("get", "");
    		environment = Env.getProperty("environment");
    		result = Env.getProperty(environment + key);
    		return result;
    	}
    	
    	return initialValue;
    }
    
    private static String getStored(String key) {
    	String result = StoredParams.retrieve(key);
    	return result;
    }
    
    private static String getArrivalTime() {
    	String result = null;
    	Instant instant = Instant.now();
    	
    	result = instant.toString();
    	
    	// truncate results to the second
    	result = result.replaceAll("\\.[0-9]{3}Z", "Z");
    	return result;
    }
}

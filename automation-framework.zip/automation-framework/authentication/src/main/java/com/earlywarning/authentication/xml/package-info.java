/**
 * 
 */
/**
 * @author cornettl
 *
 */
package com.earlywarning.authentication.xml;
/**
 * Copyright (c) 2017 Early Warning Services, LLC. All Rights Reserved.
 * 
 * Internal use only. Confidential and proprietary. You may not disclose, copy
 * or distribute this material for any purpose in any medium without the
 * expressed written consent of Early Warning Services, LLC.
 * 
 */
package com.earlywarning.authentication.common;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

/**
 * A POJO that represents the dataLookup json element of an Authentify request
 * message.
 * This class utilizes the lombok Data and the jackson JsonInclude annotations.
 * For more information about these annotations please see <a href="{@docRoot}/com/
 * earlywarning/authentication/common/package-summary.html#tags"> package-info</a> 
 * 
 * @author cornettl
 *
 */
@Data
@JsonInclude(Include.NON_EMPTY)
public class DataLookup {
	// TODO find out what else has changed for the simplified JSON
	@JsonProperty("FinalTargetUrl")
	private FinalTargetUrl finalTargetUrl;
	private MobileNetworkOperator mobileNetworkOperator;
	private DeviceIp deviceIp;
	private ConsentCollectedDate consentCollectedDate;
	private ConsentTransactionId consentTransactionId;
	private ConsentDescription consentDescription;
	private LastVerificationDate lastVerificationDate;
	private Vfp vfp;
	private EnterprisePhoneNumber enterprisePhoneNumber;
	private CallArrivalTime callArrivalTime;
	private String email;
	private Name name;
	private Address address;

}

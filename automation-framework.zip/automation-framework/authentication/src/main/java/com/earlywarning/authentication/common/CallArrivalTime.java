package com.earlywarning.authentication.common;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import lombok.Data;

/**
 * A POJO representing a CallArrivalTime element of an Authentify
 * JSON request. 
 * This class utilizes the lombok.Data and the jackson.databind.JsonInclude
 * annotations. See the <a href="{@docRoot}/com/earlywarning/authentication/common/package-summary.html#tags">
 * package-info</a> for the annotation details.
 * @author cornettl
 *
 */
@Data
@JsonInclude(Include.NON_NULL)
public class CallArrivalTime {
	private String value;
}

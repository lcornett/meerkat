/**
 * Copyright (c) 2017 Early Warning Services, LLC. All Rights Reserved.
 * 
 * Internal use only. Confidential and proprietary. You may not disclose, copy
 * or distribute this material for any purpose in any medium without the 
 * expressed written consent of Early Warning Services, LLC.
 * 
 */
package com.earlywarning.authentication.xml;

import java.util.Map;
import java.util.Set;

import com.earlywarning.authentication.xml.AuthentXML.AuthentXMLBuilder;
import com.earlywarning.authentication.xml.Header.HeaderBuilder;
import com.earlywarning.authentication.xml.Name.NameBuilder;
import com.earlywarning.authentication.xml.NamedData.NamedDataBuilder;
import com.earlywarning.authentication.startup.Env;
import com.earlywarning.authentication.xml.Address.AddressBuilder;
import com.earlywarning.authentication.xml.RequestData.RequestDataBuilder;


import lombok.extern.log4j.Log4j2;

@Log4j2
public class XmlRequestCreator {
	private static AuthentXMLBuilder requestBuilder = AuthentXML.builder();
	private static HeaderBuilder headerBuilder = null;
	private static NameBuilder nameBuilder = null;
	private static NamedDataBuilder ndBuilder = null;
	private static AddressBuilder addressBuilder = null;
	private static RequestDataBuilder dataBuilder = null;
	
	
	public static AuthentXML createRequest(Map<String, String> map) {
		Set<String> keys = map.keySet();
		AuthentXML message = null;
		XmlRequest request = new XmlRequest();
		Body body = new Body();
		Name name = null;
		Address address = null;
		RequestData data = null;
		Header header = null;
		NamedData namedData = null;
		
		try {
			keys.forEach((key) -> {;
				switch (key) {
					case "account":	
						if (null == headerBuilder) {
							headerBuilder = Header.builder();
						}
						headerBuilder.account(map.get(key));
						break;
					case "application":
						if (null == headerBuilder) {
							headerBuilder = Header.builder();
						}
						headerBuilder.application(map.get(key));
						break;
					case "asid":
						if (null == headerBuilder) {
							headerBuilder = Header.builder();
						}
						headerBuilder.asid(map.get(key));
						break;
					case "firstName":
						if (nameBuilder == null) {
							nameBuilder = Name.builder();
						}
						nameBuilder.firstName(map.get(key));
						break;
					case "lastName":
						if (nameBuilder == null) {
							nameBuilder = Name.builder();
						}
						nameBuilder.lastName(map.get(key));
						break;
					case "licenseKey":
						if (null == headerBuilder) {
							headerBuilder = Header.builder();
						}
						headerBuilder.licenseKey(map.get(key));
						break;
					case "messageText":
						if (null == ndBuilder) {
							ndBuilder = NamedData.builder();
						}
						ndBuilder.messageText(map.get(key));
						break;
					case "phoneNumber":
						if (dataBuilder == null) {
							dataBuilder = RequestData.builder();
						}
						dataBuilder.phoneNumber(map.get(key));
						break;
					case "postalCode":
						if (addressBuilder == null) {
							addressBuilder = Address.builder();
						}
						addressBuilder.postalCode(map.get(key));
						break;
					case "streetAddress":
						if (addressBuilder == null) {
							addressBuilder = Address.builder();
						}
						addressBuilder.streetAddress(map.get(key));
						break;	
					case "tsoid":
						if (null == headerBuilder) {
							headerBuilder = Header.builder();
						}
						headerBuilder.tsoid(map.get(key));
						break;
					default:
						String msg = "The tag " + key + " is unknown!";
						log.info(msg);
				}
			});
			
			if (null == headerBuilder) {
				header = getDefaultHeader();
			} else {
				header = headerBuilder.build();
				if (header.getLicenseKey() == null) {
					header.setLicenseKey(getLicenseKey());
				}
			}
			
			if (null != nameBuilder) {
				name = nameBuilder.build();
				dataBuilder.name(name);
			}
			if (null != addressBuilder) {
				address = addressBuilder.build();
				dataBuilder.address(address);
			}
			if (null != ndBuilder)	{
				namedData = ndBuilder.build();
				dataBuilder.namedData(namedData);
			}

			data = dataBuilder.build();
			
			request.setData(data);
			body.setRequest(request);
			
			requestBuilder.header(header);
			requestBuilder.body(body);
			message = requestBuilder.build();
			return message;
		} finally {
			nameBuilder = null;
			addressBuilder = null;
			dataBuilder = null;
			ndBuilder = null;
			requestBuilder = AuthentXML.builder();
		}
	}
	
	private static Header getDefaultHeader() {
		Header header = null;
		HeaderBuilder headerBuilder = Header.builder();
		
		headerBuilder.tsoid("Authentify_Sales");
		headerBuilder.application("FullDataLookup");
		headerBuilder.asid("QA_Test");
		headerBuilder.licenseKey(getLicenseKey());
		header = headerBuilder.build();
		return header;
	}
	
	private static String getLicenseKey() {
		String enviromnent = Env.getProperty("environment");
		String licenseKey = Env.getProperty(enviromnent + "License");
		
		return licenseKey;
	}
}


/**
 * Copyright (c) 2017 Early Warning Services, LLC. All Rights Reserved.
 * 
 * Internal use only. Confidential and proprietary. You may not disclose, copy
 * or distribute this material for any purpose in any medium without the 
 * expressed written consent of Early Warning Services, LLC.
 * 
 */
package com.earlywarning.authentication.xml;

import java.util.Map;
import java.util.Set;

import com.earlywarning.authentication.common.ApiDriver;

import io.restassured.response.Response;
import lombok.extern.log4j.Log4j2;

/**
 * A class that facilitates validation of Rest Response messages in XML format.
 * @author cornettl
 *
 */
@Log4j2
public class XmlResponseValidator implements XmlLookupConstants {
	private static ApiDriver driver = new ApiDriver("", "");
	private static boolean result = true;

	/**
	 * The primary method of the class. 
	 * @param response The Response message.
	 * @param map A Map of exxpected responses.
	 * @return true of the all the responses match the expected, false otherwise.
	 */
	public  static boolean validateResponse(Response response, Map<String, String> map) {
		boolean status = true;
		Set<String> keys = map.keySet();

		try {
			keys.forEach((key) -> {
				switch (key) {
					case "businessIndicator":
						validate(response, BUSINESS_INDICATOR, map.get(key));
						break;
					case "businessNameMatch":
						validate(response, BUSINESS_NAME_MATCH, map.get(key));
						break;		
					case "currentPhoneType":
						validate(response, CURRENT_PHONE_TYPE, map.get(key));
						break;
					case "firstNameMatch":
						validate(response, FIRST_NAME_MATCH, map.get(key));
						break;
					case "geolocationLatitude":
						validate(response, GEOLOCATION_LATITUDE, map.get(key));
						break;
					case "geolocationLongitude":
						validate(response, GEOLOCATION_LONGITUDE, map.get(key));
						break;
					case "geolocationName":
						validate(response, GEOLOCATION_NAME, map.get(key));
						break;
					case "geolocationPostalCode":
						validate(response, GEOLOCATION_POSTAL_CODE, map.get(key));
						break;
					case "geolocationProvinceName":
						validate(response, GEOLOCATION_PROVINCE_NAME, map.get(key));
						break;
					case "isLandline":
						validate(response, IS_LANDLINE, map.get(key));
						break;
					case "landlineIndicator":
						validate(response, LANDLINE_INDICATOR, map.get(key));
						break;
					case "lastNameMatch":
						validate(response, LAST_NAME_MATCH, map.get(key));
						break;
					case "messageText":
						validate(response, MESSAGE_TEXT, map.get(key));
						break;
					case "numberPortability":
						validate(response, NUMBER_PORTABILITY, map.get(key));
						break;
					case "originalCarrier":
						validate(response, ORIGINAL_CARRIER, map.get(key));
						break;
					case "originalPhoneType":
						validate(response, ORIGINAL_PHONE_TYPE, map.get(key));
						break;
					case "phoneToPostalDistance":
						validate(response, PHONE_TO_POSTAL_DISTANCE, map.get(key));
						break;
					case "populationDensity":
						validate(response, POPULATION_DENSITY, map.get(key));
						break;
					case "portedCarrier":
						validate(response, PORTED_CARRIER, map.get(key));
						break;
					case "postalCodeMatch":
						validate(response, POSTAL_CODE_MATCH, map.get(key));
						break;
					case "registeredCarrierName":
						validate(response, REGISTERED_CARRIER_NAME, map.get(key));
						break;
					case "statusCode":
						validate(response, STATUS_CODE, map.get(key));
						break;
					case "streetAddressMatch":
						validate(response, STREET_ADDRESS_MATCH, map.get(key));
						break;
					case "zipExchangeDistance":
						validate(response, ZIP_EXCHANGE_DISTANCE, map.get(key));
						break;
					default:
						log.info("The element " + key + " was not found!");
						
				}
			});
		} finally {
			status = result;
			result = true;
		}
		
		return status;		
	}
	
	public static boolean validateSOAPResponse(Response response, Map<String, String> map) {
		boolean status = true;
		Set<String> keys = map.keySet();

		try {
			for (String key : keys) {
				switch (key) {
					case "statusCode":
						validate(response, "//statusCode/text()", map.get(key));
						break;
					case "zipExchangeDistance":
						validate(response, "//zipExchangeDistance/text()", map.get(key));
						break;
					default:
					log.info("The element " + key + " is not implemented.");
				}
			}
		} finally {
			status = result;
			result = true;
		}
		return status;
	}
	
	/**
	 * A method to compare the actual with the expected and update the 
	 * result property of the class. The key to get the actual value
	 * being compared is used.
	 * @param response The message response
	 * @param key The key used to validate. 
	 * @param expected The expected value
	 */
	private static void validate(Response response, String key, String expected) {
		String actual = null;
		
		actual = driver.retrieveXMLvaluefromTag(response, key);
		
		if (!expected.equals(actual)) {
			String msg = "The actual value for key " + key + " is " + actual + " and does not equal the expected value " + expected + ".";
			log.info(msg);
			updateResult(false);
		} else {
			log.info("The " + key + " element was successfully validated");
		}
		
		
	}
	
	/**
	 * Updates the result property.
	 * @param status The status of the last comparison.
	 */
	private static void updateResult(boolean status) {
		if (result == true && status == false) {
			result = false;
		}
	}

}


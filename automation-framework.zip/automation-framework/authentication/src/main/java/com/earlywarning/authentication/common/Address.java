package com.earlywarning.authentication.common;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import lombok.Data;

/**
 * A Java POJO representing the Address element of an Authentify
 * JSON Request. This class utilizes the lombok.Data annotation to
 * implement the setters and getters for the following private 
 * properties:<ul>
 * 	<li>streetAddress</li>
 * 	<li>extendedAddress</li>
 * 	<li>city</li>
 * 	<li>postalCode</li>
 * 	<li>region</li>
 * 	<li>country</li></ul>
 * The properties of this class are named objects (e.g., StreetAddress = streetAddress)
 * @author cornettl
 *
 */
@Data
@JsonInclude(Include.NON_NULL)
public class Address {
	private StreetAddress streetAddress;
	private ExtendedAddress extendedAddress;
	private City city;
	private PostalCode postalCode;
	private Region region;
	private Country country;
}

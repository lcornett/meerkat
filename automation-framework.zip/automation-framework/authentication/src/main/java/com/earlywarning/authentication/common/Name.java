package com.earlywarning.authentication.common;

import lombok.Data;

@Data
//@JsonInclude(Include.NON_NULL)
public class Name {
	private FirstName firstName;
	private MiddleName middleName;
	private LastName lastName;
	
}

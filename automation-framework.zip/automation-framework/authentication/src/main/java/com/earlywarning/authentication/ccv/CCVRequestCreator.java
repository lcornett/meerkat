/**
 * Copyright (c) 2017 Early Warning Services, LLC. All Rights Reserved.
 * 
 * Internal use only. Confidential and proprietary. You may not disclose, copy
 * or distribute this material for any purpose in any medium without the 
 * expressed written consent of Early Warning Services, LLC.
 * 
 */
package com.earlywarning.authentication.ccv;

import static com.earlywarning.authentication.ccv.CCVFieldConstants.*;
import static com.earlywarning.authentication.ccv.CCVFieldConstants.CALL_ARRIVAL_TIMESTAMP;
import static com.earlywarning.authentication.ccv.CCVFieldConstants.CONSENT_COLLECTED_TIMESTAMP;
import static com.earlywarning.authentication.ccv.CCVFieldConstants.CONSENT_DESCRIPTION;
import static com.earlywarning.authentication.ccv.CCVFieldConstants.CONSENT_STATUS;
import static com.earlywarning.authentication.ccv.CCVFieldConstants.CONSENT_TRANSACTION_ID;
import static com.earlywarning.authentication.ccv.CCVFieldConstants.EMAIL_ADDRESS;
import static com.earlywarning.authentication.ccv.CCVFieldConstants.MOBILE_CALL_VERIFICATION_CHECK;
import static com.earlywarning.authentication.ccv.CCVFieldConstants.MOBILE_CALL_VERIFICATION_DID;
import static com.earlywarning.authentication.ccv.CCVFieldConstants.MOBILE_IDENTITY_CHECK;
import static com.earlywarning.authentication.ccv.CCVFieldConstants.MOBILE_NUMBER;
import static com.earlywarning.authentication.ccv.CCVFieldConstants.MOBILE_STATUS_CHECK;
import static com.earlywarning.authentication.ccv.CCVFieldConstants.PAYFONE_ALIAS;
import static com.earlywarning.authentication.ccv.CCVFieldConstants.REQUESTID;

import java.util.Map;
import java.util.Set;

import com.earlywarning.authentication.ccv.CCVRequest.CCVRequestBuilder;
import com.earlywarning.authentication.ccv.MatchAddressAttributeKey.MatchAddressAttributeKeyBuilder;
import com.earlywarning.authentication.ccv.MatchEmailAttributeKey.MatchEmailAttributeKeyBuilder;
import com.earlywarning.authentication.ccv.MatchNameAttributeKey.MatchNameAttributeKeyBuilder;

import lombok.extern.log4j.Log4j2;

@Log4j2
public class CCVRequestCreator {
	static CCVRequestBuilder requestBuilder = CCVRequest.builder();
	static MatchEmailAttributeKeyBuilder emailBuilder = null;
	static MatchNameAttributeKeyBuilder nameBuilder = null;
	static MatchAddressAttributeKeyBuilder addressBuilder = null;
	
	public static CCVRequest createRequest(Map<String, String> args) {
		Set<String> keys = args.keySet();
		CCVRequest request= null;
		MatchEmailAttributeKey emailKey = null;
		MatchNameAttributeKey nameKey = null;
		MatchAddressAttributeKey addressKey = null;
		MobileIdentityMatchAttribute mima = new MobileIdentityMatchAttribute();
		
		try {
			for (String key : keys) {
				switch (key) {
				case API_CLIENT_ID:
					requestBuilder.apiClientId(args.get(key));
					break;
				case CALL_ARRIVAL_TIMESTAMP:
					requestBuilder.callArrivalTimestamp(args.get(key));
					break;
				case CITY:
					if (null == addressBuilder) {
						addressBuilder = MatchAddressAttributeKey.builder();
					}
					addressBuilder.City(args.get(key));
					break;
				case CONSENT_COLLECTED_TIMESTAMP:
					requestBuilder.consentCollectedTimestamp(args.get(key));
					break;
				case CONSENT_DESCRIPTION:
					requestBuilder.consentDescription(args.get(key));
					break;
				case CONSENT_STATUS:
					requestBuilder.consentStatus(args.get(key));
					break;
				case CONSENT_TRANSACTION_ID:
					requestBuilder.consentTransactionId(args.get(key));
					break;
				case COUNTRY:
					if (null == addressBuilder) {
						addressBuilder = MatchAddressAttributeKey.builder();
					}
					addressBuilder.Country(args.get(key));
					break;
				case EMAIL_ADDRESS:
					if (null == emailBuilder) {
						emailBuilder = MatchEmailAttributeKey.builder();
					}
					emailBuilder.emailAddress(args.get(key));
					break;
				case EXTENDED_ADDRESS:
					if (null == addressBuilder) {
						addressBuilder = MatchAddressAttributeKey.builder();
					}
					addressBuilder.ExtendedAddress(args.get(key));
					break;
				case FIRST_NAME:
					if (null == nameBuilder) {
						nameBuilder = MatchNameAttributeKey.builder();
					}
					nameBuilder.FirstName(args.get(key));
					break;
				case LAST_NAME:
					if (null == nameBuilder) {
						nameBuilder = MatchNameAttributeKey.builder();
					}
					nameBuilder.LastName(args.get(key));
					break;
				case MIDDLE_NAME:
					if (null == nameBuilder) {
						nameBuilder = MatchNameAttributeKey.builder();
					}
					nameBuilder.MiddleName(args.get(key));
					break;
				case MOBILE_CALL_VERIFICATION_CHECK:
					requestBuilder.MobileCallVerificationCheck(Boolean.parseBoolean(args.get(key)));
					break;
				case MOBILE_CALL_VERIFICATION_DID:
					requestBuilder.mobileCallVerificationDID(args.get(key));
					break;
				case MOBILE_IDENTITY_CHECK:
					requestBuilder.MobileIdentityCheck(Boolean.parseBoolean(args.get(key)));
					break;
					
				case MOBILE_NUMBER:
					requestBuilder.mobileNumber(args.get(key));
					break;
				case MOBILE_STATUS_CHECK:
					requestBuilder.MobileStatusCheck(Boolean.parseBoolean(args.get(key)));
					break;
				case PAYFONE_ALIAS:
					requestBuilder.payfoneAlias(args.get(key));
					break;
				case POSTAL_CODE:
					if (null == addressBuilder) {
						addressBuilder = MatchAddressAttributeKey.builder();
					}
					addressBuilder.PostalCode(args.get(key));
					break;
				case REGION:
					if (null == addressBuilder) {
						addressBuilder = MatchAddressAttributeKey.builder();
					}
					addressBuilder.Region(args.get(key));
					break;
				case REQUESTID:
					requestBuilder.requestId(args.get(key));
					break;
				case STREET_ADDRESS:
					if (null == addressBuilder) {
						addressBuilder = MatchAddressAttributeKey.builder();
					}
					addressBuilder.StreetAddress(args.get(key));
					break;
				default:
					String msg = "The element " + key + " was not found!";
					log.warn(msg);
				}				
			}
			
			// put it all together
			if (null != emailBuilder) {
				emailKey = emailBuilder.build();
				mima.setMatchEmailAttributeKey(emailKey);
			}
			
			if (null != nameBuilder) {
				nameKey = nameBuilder.build();
				mima.setMatchNameAttributeKey(nameKey);
			}
			
			if (null != addressBuilder) {
				addressKey = addressBuilder.build();
				mima.setMatchAddressAttributeKey(addressKey);
			}
			
			requestBuilder.mobileIdentityMatchAttribute(mima);
			request = requestBuilder.build();	
			return request;
		} finally {
			emailBuilder = null;
			nameBuilder = null;
			addressBuilder = null;
			requestBuilder = CCVRequest.builder();
		}

	}
	
}

